﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PingPong.DataContract
{

    public class SkillLevelDTO
    {
        public int SkillLevelId { get; set; }

        public string Description { get; set; }
    }
}
